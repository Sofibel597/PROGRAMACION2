<?php
namespace Contratos;

interface Renderable {
    public function renderizar();
}
