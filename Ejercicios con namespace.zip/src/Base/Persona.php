<?php
namespace Base;

class Persona {
    public function saludar() {
        return "Hola, soy una persona.";
    }
}
