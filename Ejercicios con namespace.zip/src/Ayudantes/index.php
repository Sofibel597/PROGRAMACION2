require 'src/Ayudantes/funciones.php';
use function Ayudantes\saludar;
echo saludar();

