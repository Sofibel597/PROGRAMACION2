<?php
namespace Ayudantes;
function saludar() {
    return "¡Hola desde función ayudante!";
}

