<?php
namespace Modelos;

class Usuario {
    public function obtenerNombre() {
        return "Sofi <3";
    }
}
