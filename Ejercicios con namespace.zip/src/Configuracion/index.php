use Configuracion\ConfiguracionApp;
echo ConfiguracionApp::NOMBRE_APP;

