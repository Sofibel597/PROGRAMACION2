<?php
namespace Configuracion;
class ConfiguracionApp {
    public const NOMBRE_APP = "Mi Aplicación";
}
