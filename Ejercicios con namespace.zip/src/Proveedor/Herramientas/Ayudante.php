<?php
namespace Proveedor\Herramientas;

class Ayudante {
    public static function ayudar() {
        return "Ayudando desde Ayudante";
    }
}
