use Proveedor\Herramientas\Ayudante as AyudaProveedor;
echo AyudaProveedor::ayudar();

