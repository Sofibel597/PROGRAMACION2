<?php
namespace Utilidades;

class Matematica {
    public static function sumar($a, $b) {
        return $a + $b;
    }
}
